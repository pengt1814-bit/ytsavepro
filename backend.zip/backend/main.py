from flask import Flask, request, jsonify, send_file, Response
from flask_cors import CORS
import yt_dlp
import os
import tempfile
import threading
import time
import uuid

app = Flask(__name__, static_folder='static', static_url_path='')
CORS(app)

# Temp folder for downloads
DOWNLOAD_DIR = tempfile.gettempdir()

# Progress tracking
progress_store = {}

def cleanup_file(path, delay=60):
    """Delete file after delay seconds"""
    def _del():
        time.sleep(delay)
        try:
            if os.path.exists(path):
                os.remove(path)
        except:
            pass
    threading.Thread(target=_del, daemon=True).start()

@app.route('/')
def index():
    return app.send_static_file('index.html')

@app.route('/api/info', methods=['POST'])
def get_info():
    """Get video info + thumbnail"""
    data = request.json
    url = data.get('url', '').strip()
    if not url:
        return jsonify({'error': 'No URL provided'}), 400

    try:
        ydl_opts = {
            'quiet': True,
            'no_warnings': True,
            'skip_download': True,
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            return jsonify({
                'title':     info.get('title', 'Unknown'),
                'duration':  info.get('duration_string', ''),
                'views':     info.get('view_count', 0),
                'thumbnail': info.get('thumbnail', ''),
                'uploader':  info.get('uploader', ''),
                'video_id':  info.get('id', ''),
            })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/download', methods=['POST'])
def download_video():
    """Download video or audio and stream to user"""
    data = request.json
    url     = data.get('url', '').strip()
    mode    = data.get('mode', 'video')       # 'video' or 'audio'
    quality = data.get('quality', '1080p')    # e.g. '1080p', '720p', '320kbps'

    if not url:
        return jsonify({'error': 'No URL provided'}), 400

    job_id   = str(uuid.uuid4())
    out_path = os.path.join(DOWNLOAD_DIR, f'{job_id}')

    try:
        if mode == 'audio':
            # Extract MP3
            kbps = quality.replace('kbps', '')
            ydl_opts = {
                'format': 'bestaudio/best',
                'outtmpl': out_path + '.%(ext)s',
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': kbps,
                }],
                'quiet': True,
            }
            ext = 'mp3'
            mime = 'audio/mpeg'
        else:
            # Video + Audio
            height = quality.replace('p', '')
            ydl_opts = {
                'format': f'bestvideo[height<={height}]+bestaudio/best[height<={height}]/best',
                'outtmpl': out_path + '.%(ext)s',
                'merge_output_format': 'mp4',
                'quiet': True,
            }
            ext = 'mp4'
            mime = 'video/mp4'

        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            title = info.get('title', 'video')

        # Find the downloaded file
        final_path = None
        for f in os.listdir(DOWNLOAD_DIR):
            if f.startswith(job_id):
                final_path = os.path.join(DOWNLOAD_DIR, f)
                break

        if not final_path or not os.path.exists(final_path):
            return jsonify({'error': 'Download failed'}), 500

        # Safe filename
        safe_title = "".join(c for c in title if c.isalnum() or c in ' -_').strip()[:60]
        filename = f"{safe_title}.{ext}"

        # Schedule cleanup
        cleanup_file(final_path, delay=120)

        return send_file(
            final_path,
            mimetype=mime,
            as_attachment=True,
            download_name=filename
        )

    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
